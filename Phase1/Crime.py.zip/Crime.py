#Steven Chang

# -*- coding: utf-8 -*-


import requests
import pprint


#crime.txt
url = "https://data.montgomerycountymd.gov/resource/yc8a-5df8.json?$$app_token=tX2XTxtf7mZd8F5eQ7enqtsPO"

response = requests.get(url)

data = response.json()

f = open("crime.txt","w")
f.write(response.text)
f.close()

#downloaded data
print("\nTotal amount of downloaded data:",len(data))
print("\nTotal amount of attributes:",len(data[0]))


#count null narrative

count = 0
d = 0
for d in data:
    if "narrative" not in d:
        count += 1

print("\n\n\nTotal number of 'null' narrative(Class Description):\n" ,count)


#ratio of null narrative

ratio_nar = 0
ratio_nar = (count / len(data)) * 100
print("\nPercentage of the 'null' narrative received in the attribute narrative:\n", ratio_nar, "%")

#count null places

count = 0
d = 0
for d in data:
    if "place" not in d:
        count += 1

print("\n\n\nTotal number of 'null' places:\n" ,count)


#ratio of null place

ratio_place = 0
ratio_place = (count / len(data)) * 100
print("\nPercentage of the 'null' places received in the attribute place:\n", ratio_place, "%")


#count null zip

count = 0
d = 0
for d in data:
    if "zip_code" not in d:
        count += 1

print("\n\n\nTotal number of 'null' zipcode:\n" ,count)


#ratio of null zip

ratio_zip = 0
ratio_zip = (count / len(data)) * 100
print("\nPercentage of the 'null' zipcode in the attribute zipcode:\n", ratio_zip, "%")




#count null end date/time

count = 0
d = 0
for d in data:
    if "end_date" not in d:
        count += 1

print("\n\nTotal number of empty end date/time:\n" ,count)

#ratio of end date/time

ratio_end = 0
ratio_end = (count / len(data)) * 100
print("\nPercentage of the null end date/time:\n", ratio_end, "%")





#counting Agency not MCPD
count = 0
d = 0
for d in data:
    if d["agency"] != "MCPD":
        count += 1

print("\n\nTotal number of Agencies is not MCPD:\n" ,count)

#ratio of Agency not MCPD
ratio_agency = 0
ratio_agency = (count / len(data)) * 100
print("\nPercentage of the Agency which is not MCPD:\n", ratio_agency, "%")

#count class description with value of stolen belongings in the statement
count = 0
d = 0
for d in data:
    if "$" in d["narrative"]:
        count += 1

print("\n\nClass description with value of stolen belongings:\n", count)

#percent of the total of class description with fine
ratio_fine = 0
ratio_fine = (count / len(data)) * 100

print("\nPercentage of the Class description with value of stolen belongings:\n", ratio_fine, "%\n\n")



#calculate total of each different cities
count = 0
d = 0
district = {}
for d in data:
    if d["district"] not in district:
        district[d["district"]] = 0
    district[d["district"]] += 1

#highest crime occur district

print("Show from high to low in the amounts of crime occur in each district:\n")
pprint.pprint([(w, district[w]) for w in sorted(district, key=district.get, reverse=True)])



#seperate the TOP THREE CRIME RATE districts into 2014 2015 2016

print("\n\nTOP THREE Crime Rate Districts:")

d = 0
count = 0
for d in data:
    if d["district"] == "SILVER SPRING":
        if "2014" in d["start_date"]:
            count += 1

print("\nTop 1:\nCrime occurred in Silver Spring 2014\n",count)

d = 0
count = 0
for d in data:
    if d["district"] == "SILVER SPRING":
        if "2015" in d["start_date"]:
            count += 1

print("Top 1:\nCrime occurred in Silver Spring 2015\n",count)

d = 0
count = 0
for d in data:
    if d["district"] == "SILVER SPRING":
        if "2016" in d["start_date"]:
            count += 1

print("Top 1:\nCrime occurred in Silver Spring 2016\n",count)

d = 0
count = 0
for d in data:
    if d["district"] == "WHEATON":
        if "2014" in d["start_date"]:
            count += 1

print("\n\nTop 2:\nCrime occurred in Wheaton 2014\n",count)

d = 0
count = 0
for d in data:
    if d["district"] == "WHEATON":
        if "2015" in d["start_date"]:
            count += 1

print("Top 2:\nCrime occurred in Wheaton 2015\n",count)

d = 0
count = 0
for d in data:
    if d["district"] == "WHEATON":
        if "2016" in d["start_date"]:
            count += 1

print("Top 2:\nCrime occurred in Wheaton 2016\n",count)

d = 0
count = 0
for d in data:
    if d["district"] == "MONTGOMERY VILLAGE":
        if "2014" in d["start_date"]:
            count += 1

print("\n\nTop 3:\nCrime occurred in Montgomery Village 2014\n",count)

d = 0
count = 0
for d in data:
    if d["district"] == "MONTGOMERY VILLAGE":
        if "2015" in d["start_date"]:
            count += 1

print("Top 3:\nCrime occurred in Montgomery Village 2015\n",count)

d = 0
count = 0
for d in data:
    if d["district"] == "MONTGOMERY VILLAGE":
        if "2016" in d["start_date"]:
            count += 1

print("Top 3:\nCrime occurred in Montgomery Village 2016\n",count)

#calculate total of each place crime occured
count = 0
d = 0
place = {}
for d in data:
    if d["place"] not in place:
        place[d["place"]] = 0
    place[d["place"]] += 1

#Child abuse in single family from 2013 to 2016
print("\n\nChild abuse in single family from 2013 to 2016:\n")

d = 0
count = 0
for d in data:
    if "Single Family" in d["place"]:
        if "ABUSE/CHILD" in d["narrative"]:
            if "2013" in d["start_date"]:
                count += 1

print("abuse2013\n",count)

d = 0
count = 0
for d in data:
    if "Single Family" in d["place"]:
        if "ABUSE/CHILD" in d["narrative"]:
            if "2014" in d["start_date"]:
                count += 1

print("abuse2014\n",count)

#
d = 0
count = 0
for d in data:
    if "Single Family" in d["place"]:
        if "ABUSE/CHILD" in d["narrative"]:
            if "2015" in d["start_date"]:
                count += 1

print("abuse2015\n",count)

#
d = 0
count = 0
for d in data:
    if "Single Family" in d["place"]:
        if "ABUSE/CHILD" in d["narrative"]:
            if "2016" in d["start_date"]:
                count += 1

print("abuse2016\n",count)

#highest crime occur district

print("\n\n\nShow from high to low in crime occur in different places:\n")
pprint.pprint([(w, place[w]) for w in sorted(place, key=place.get, reverse=True)])

#calculate total of each class description of crime
count = 0
d = 0
narrative = {}
for d in data:
    if d["narrative"] not in narrative:
        narrative[d["narrative"]] = 0
    narrative[d["narrative"]] += 1

#highest crime occur district

print("\n\n\nShow from high to low in the class description of crime:\n")
pprint.pprint([(w, narrative[w]) for w in sorted(narrative, key=narrative.get, reverse=True)])






